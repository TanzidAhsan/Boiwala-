 <!DOCTYPE html>





<html lang="en">
    <head>
  
  <title>Upload</title>

  <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <link rel="stylesheet" href="css/style.css">

    <style type="text/css">
      
      .brand-text{
         color: #blue; !important;
         text-align: right;
         
      }
      form{
        max-width: 400px;
        margin: 10px auto;
        padding: 10px;
      }
    </style>
</head>

<body>
<?php include 'header_seller.php'; ?>
</div>

<body>
<h1 style="text-align: center; display: block;
  font-size: 4em;
  margin-top: 0em;
  margin-bottom: 0em;
  margin-left: 1;
  margin-right: 1;
  font-weight: thick;"><a href="test.php" class="brand-logo brand-text"> BOIWALA</a></h1>
  <?php include 'header_info.php'; ?>
   <?php
   $host = "localhost";
   $user= "root";
   $password ="";
   $db ="boi";
   $data=mysqli_connect($host,$user,$password,$db);
   if($data===false)
   {
    die("connection is fail");

   }
   
   if(isset($_POST['submit']))
   {

    $sname =$_POST['name'];
    $sisbn =$_POST['isbn'];
    $sprice=$_POST['price'];
    $file=$_FILES['uploaded_image']['name'];
    $dst="./uploaded_image/".$file;
    $dst_db=$file;
    $scatagory = $_POST['Catagory'];
    $seller_id = $_POST['seller_id'];

    move_uploaded_file($_FILES['uploaded_image']['tmp_name'],$dst);

    $query="INSERT INTO books(isbn,name,img,price,Catagory,seller_id) VALUES('$sisbn','$sname','$dst_db','$sprice','$scatagory','$seller_id')";
    

    $result=mysqli_query($data,$query);

    if($result)
    {
    
    }
    else
    {
        echo"failed";
    }
   }
   
   ?>














    <div align="center">
        <form action="upload_book.php" method="POST" enctype="multipart/form-data">


        <div>
          <label>BOIWALA Name</label>
          <input type="text" name="name">
        </div>
        <div>
          <label>BOIWALA isbn</label>
          <input type="number" name="isbn">
        </div>
                <div>
          <label>BOIWALA img</label>
          <input type="File" name="uploaded_image">
        </div>
        <br>
         <div>
          <label>BOIWALA price</label>
          <input type="number" name="price">
        </div>
        <div>
          <label>BOIWALA Category</label>
          <input type="text" name="Catagory">
        </div>
        <div>
          <label>BOIWALA seller_id</label>
          <input type="text" name="seller_id">
        </div>
        <div>
          <input type="submit" name="submit" value="Upload">
        </div>
   </form>
   </div>
</body>
<?php include 'footer_seller.php';
?>
</html>
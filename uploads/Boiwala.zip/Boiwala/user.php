<!DOCTYPE html>


<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>user page</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
<?php include 'header_admin.php'; ?>
 
<?php include 'header.php'; ?>


<div class="heading">
   <!--<h3>search page</h3>-->

   <head> <h1 style="text-align: center; display: block;
  font-size: 4em;
  margin-top: 0em;
  margin-bottom: 0em;
  margin-left: 1;
  margin-right: 1;
  font-weight: thick;"><a href="test.php" class="brand-logo brand-text">BOIWALA</a></h1> </head>
  <?php include 'info_user.php'; ?>
</div>
<form action="" method="post">
   <td><center><input type="submit" name="submit" value="Show users" class="btn">
      </center></td>
   <table class="table">
   <thead>
      <tr>
         <!--<section class="search-form">-->
      <th>Name</th>    
      <th>Email</th>  
      </tr>
   </thead>


<!--<section class="users" style="padding-top: 0;">

   <div class="box-container">-->
   <?php

   include('config.php');

      if(isset($_POST['submit'])){
         $search_user = $_POST['submit'];
         $select_user = mysqli_query($conn, "SELECT * FROM `users`") or die('query failed');
         if(mysqli_num_rows($select_user) > 0){
         while($fetch_user = mysqli_fetch_assoc($select_user)){

      if(isset($_POST['Delete'])){
         $search_id = $_POST['Email'];
         $select_id = mysqli_query($conn, "DELETE * FROM `users`WHERE Email = $search_id") or die('query failed');

      }
   ?>

   <tbody>
      <tr>
            <form action="" method="post" class="box">

      <td class="name"><?php echo $fetch_user['name']; ?></td>
      <td class="name"><?php echo $fetch_user['Email']; ?></td>
      <div><td><input type="submit" name="delete" value="Block"></td></div>

      </tr>
   </tbody>
   <?php
            }
         }
      }
   
   ?>
   

</div>
</section>


</table>


<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/e8ad96c874.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="seller_fst.css" />
</head>
<body>
<?php include 'header_seller.php'; ?>

<h1 style="text-align: center; display: block;
  font-size: 4em;
  margin-top: 0em;
  margin-bottom: 0em;
  margin-left: 1;
  margin-right: 1;
  font-weight: thick;"><a href="test.php" class="brand-logo brand-text"> BOIWALA</a></h1>
  <?php include 'header_info.php'; ?>
<table class="table table-striped">
  <thead>
    <tr>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td><i class="fa-solid fa-upload"></i><a href="upload_book.php"><button class="register">Upload A Book</button></a></td>
      <td><i class="fa-solid fa-upload"></i><a href="mybooks.php"><button class="register">My Books</button></td>
      <td></td>
    </tr>
  </tbody>
</table>
    
</body>
<?php include 'footer_seller.php';
?>
</html>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="style2.css" />
    <title></title>
  </head>
  <body>
    <?php
    session_start();
    include ('config.php');
    if(isset($_POST['login'])){
        $Email = mysqli_real_escape_string($conn, $_POST['Email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        if(!empty($Email) && !empty($password)){
            $query = "select * from users where Email = '".$Email."' AND password = '".$password."' limit 1";
            $result = mysqli_query($conn,$query);
            $data = $result->fetch_assoc() ;
                if($result && mysqli_num_rows($result) > 0){
                    $_SESSION['Email'] = $data['Email'];
                    $_SESSION['Password'] = $data['password'];
                    $_SESSION['name']= $data['name'];

                    header("Location: test.php");
                    die;
                }
                else{
                    echo '<script>alert("Log-in unsuccessful!")</script>' ;
                }
        }

    }


    ?>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
            <form  action="" class="sign-in-form" method="POST">
                <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name = "Email" placeholder="Email" />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name ="password" placeholder="Password" />
            </div>
              <a href="test.php"><input type="submit" name = "login" value="Login" class="btn solid" /></a>
            </form>
            <div class="move"><p class="social-text">Don't have an account? <a href="signup.php"><button class="register">Register</button></a></p>
            <div class="move2"><p class="social-text2">Login As Adminstrator,<a href="Admin_login.php"><button class="register">Admin</button></a></p>
            
            </div>
            
              
          
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            
          </div>
          
        </div>
        <div class="panel right-panel">
          
        </div>
      </div>
    </div>

    
  </body>
</html>

<?php
session_start();
include ('config.php');
$email=$_SESSION['Email'];
?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Antonio:wght@700&family=Heebo&family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="mybooks.css">
    </head>

    











   



<body>
<?php include 'header_seller.php'; ?>

<div>


<h1>My Books</h1>
</div>
    <?php
  $sql="SELECT *
  FROM `books`
  WHERE seller_id='$email'";
  $result = mysqli_query($conn,$sql);
  
      while($data = $result->fetch_assoc()){
         //$num= $data['n'];
         $name=$data['name'];
         $img=$data['img'];
          echo"  

         
          <div class='card' style='width: 18rem;'>
        <img src='./uploaded_image/$img' class='card-img-top'>
        <div class='card-body'>
          <h3 class='card-title'>$name</h3>
        </div>
      </div>";
      }
      ?>
    
</body>
<?php include 'footer_seller.php';
?>
</html>